# OWASP Juice Shop Write-ups

My notes from working through [OWASP Juice Shop](https://owasp.org/www-project-juice-shop/), a deliberately vulnerable web app built for security training. Everything here was done on my own local copy (Docker, `localhost:3000`). No real systems were touched.

| # | Challenge | Difficulty | Category | Write-up |
|---|-----------|------------|----------|----------|
| 1 | Score Board | ⭐ | Miscellaneous | [Read](01-score-board/README.md) |

**Setup:** Windows laptop, Docker Desktop + WSL 2, `docker run -d -p 3000:3000 bkimminich/juice-shop`, Microsoft Edge DevTools.

*Ugwu Kingsley · [github.com/buccitech](https://github.com/buccitech) · X [@Lucaswilliamsq](https://x.com/Lucaswilliamsq)*
